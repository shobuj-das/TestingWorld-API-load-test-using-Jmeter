/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 98.72980501392757, "KoPercent": 1.2701949860724233};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.031030640668523676, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0802407221664995, 500, 1500, "create student"], "isController": false}, {"data": [0.05215646940822467, 500, 1500, "create technical skill"], "isController": false}, {"data": [0.06720160481444333, 500, 1500, "get specific student"], "isController": false}, {"data": [5.015045135406219E-4, 500, 1500, "final student details"], "isController": false}, {"data": [0.0010030090270812437, 500, 1500, "get deleted details"], "isController": false}, {"data": [0.014042126379137413, 500, 1500, "get address by id"], "isController": false}, {"data": [0.03761283851554664, 500, 1500, "create student address"], "isController": false}, {"data": [0.008008008008008008, 500, 1500, "student details"], "isController": false}, {"data": [0.018555667001003008, 500, 1500, "delete"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 8975, 114, 1.2701949860724233, 39646.69838440112, 77, 374667, 14980.0, 109075.00000000001, 116562.39999999995, 126537.2, 17.48408412620489, 26.78560394482822, 3.9376686160933447], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["create student", 997, 3, 0.30090270812437314, 10743.437311935792, 114, 338918, 8710.0, 12327.600000000002, 24099.0, 85250.68, 2.190366342615478, 1.0425527441368705, 0.6802972414455978], "isController": false}, {"data": ["create technical skill", 997, 3, 0.30090270812437314, 14791.841524573743, 130, 114914, 11602.0, 19368.200000000004, 57026.09999999999, 81077.85999999993, 2.0475474612054447, 0.6644188505290354, 0.6318122155613607], "isController": false}, {"data": ["get specific student", 997, 4, 0.4012036108324975, 11016.806419257784, 125, 331967, 10055.0, 14419.8, 15736.69999999997, 48130.639999999985, 2.1171009519522133, 0.9678280650451131, 0.32324252551350846], "isController": false}, {"data": ["final student details", 997, 3, 0.30090270812437314, 81144.03911735202, 1167, 129248, 91499.0, 124197.0, 126057.5, 127325.72, 1.9679871459054223, 1.4472048309199008, 0.30937359050569574], "isController": false}, {"data": ["get deleted details", 997, 3, 0.30090270812437314, 84882.4613841524, 815, 130305, 92975.0, 121270.0, 125581.3, 129018.8, 1.9634294041769644, 0.6314053468741692, 0.3086570995844698], "isController": false}, {"data": ["get address by id", 997, 3, 0.30090270812437314, 39090.21263791369, 374, 116352, 27077.0, 81961.6, 107742.3, 114009.59999999999, 2.011585278504688, 0.9952788527305706, 0.29658296263434947], "isController": false}, {"data": ["create student address", 997, 4, 0.4012036108324975, 23150.502507522564, 215, 321348, 13829.0, 69419.6, 107873.89999999998, 115194.54, 2.039630616144382, 0.6676695244765902, 0.8655276470191116], "isController": false}, {"data": ["student details", 999, 88, 8.80880880880881, 15829.272272272265, 758, 374667, 9243.0, 21037.0, 26776.0, 368485.0, 2.656582820764426, 27.379722481498323, 0.35013700082702426], "isController": false}, {"data": ["delete", 997, 3, 0.30090270812437314, 76219.49047141435, 77, 115089, 82629.0, 110168.20000000001, 112391.1, 113773.42, 1.9726090277035822, 0.6456953453005607, 0.4680629967383691], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400/Bad Request", 6, 5.2631578947368425, 0.06685236768802229], "isController": false}, {"data": ["405/Method Not Allowed", 6, 5.2631578947368425, 0.06685236768802229], "isController": false}, {"data": ["404/Not Found", 6, 5.2631578947368425, 0.06685236768802229], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to www.thetestingworldapi.com:443 [www.thetestingworldapi.com/103.235.104.116] failed: Connection timed out: connect", 73, 64.03508771929825, 0.8133704735376045], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 23, 20.17543859649123, 0.2562674094707521], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 8975, 114, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to www.thetestingworldapi.com:443 [www.thetestingworldapi.com/103.235.104.116] failed: Connection timed out: connect", 73, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 23, "400/Bad Request", 6, "405/Method Not Allowed", 6, "404/Not Found", 6], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["create student", 997, 3, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["create technical skill", 997, 3, "400/Bad Request", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["get specific student", 997, 4, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 4, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["final student details", 997, 3, "404/Not Found", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["get deleted details", 997, 3, "404/Not Found", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["get address by id", 997, 3, "405/Method Not Allowed", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["create student address", 997, 4, "400/Bad Request", 3, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 1, "", "", "", "", "", ""], "isController": false}, {"data": ["student details", 999, 88, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to www.thetestingworldapi.com:443 [www.thetestingworldapi.com/103.235.104.116] failed: Connection timed out: connect", 73, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 15, "", "", "", "", "", ""], "isController": false}, {"data": ["delete", 997, 3, "405/Method Not Allowed", 3, "", "", "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
