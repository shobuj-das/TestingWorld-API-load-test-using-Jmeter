/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 96.94173673636432, "KoPercent": 3.0582632636356872};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.024294962422799316, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.06630944407233758, 500, 1500, "create student"], "isController": false}, {"data": [0.041192230408573345, 500, 1500, "create technical skill"], "isController": false}, {"data": [0.05659745478901541, 500, 1500, "get specific student"], "isController": false}, {"data": [3.348961821835231E-4, 500, 1500, "final student details"], "isController": false}, {"data": [0.0010046885465505692, 500, 1500, "get deleted details"], "isController": false}, {"data": [0.008707300736771601, 500, 1500, "get address by id"], "isController": false}, {"data": [0.03014065639651708, 500, 1500, "create student address"], "isController": false}, {"data": [0.007357859531772575, 500, 1500, "student details"], "isController": false}, {"data": [0.007032819825853985, 500, 1500, "delete"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 13439, 411, 3.0582632636356872, 30666.53411712177, 15, 442486, 22526.0, 57602.0, 67224.0, 381519.60000000003, 1.4322839509593819, 2.2002168830364144, 0.32027103001614854], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["create student", 1493, 27, 1.8084393837910249, 15546.271265907571, 78, 331050, 6982.0, 25484.800000000003, 31373.5, 324079.1, 0.164498800910616, 0.08505350401314271, 0.050318492967869076], "isController": false}, {"data": ["create technical skill", 1493, 33, 2.2103148024112524, 14717.668452779624, 88, 140987, 9629.0, 31234.0, 43727.59999999999, 53026.99999999999, 0.15930011234232302, 0.053662216422059726, 0.04893895442042874], "isController": false}, {"data": ["get specific student", 1493, 28, 1.8754186202277294, 12822.14199598126, 15, 331247, 7633.0, 26922.2, 30790.399999999994, 53319.06, 0.15927411117204943, 0.10449738203181065, 0.023939477151259304], "isController": false}, {"data": ["final student details", 1493, 28, 1.8754186202277294, 42474.4715338245, 716, 332927, 40022.0, 67890.40000000001, 72001.79999999999, 76198.0, 0.15968252589733986, 0.11679861726617313, 0.025066957968735596], "isController": false}, {"data": ["get deleted details", 1493, 27, 1.8084393837910249, 45585.27126590754, 655, 78806, 45877.0, 67953.0, 71146.0, 75107.09999999999, 0.1597672128572263, 0.05161361557616894, 0.02509707707462488], "isController": false}, {"data": ["get address by id", 1493, 31, 2.0763563295378433, 24894.05626255857, 403, 325725, 24163.0, 51834.8, 54501.1, 58270.439999999995, 0.15954763276943806, 0.07887225754797622, 0.023488743690094165], "isController": false}, {"data": ["create student address", 1493, 31, 2.0763563295378433, 18975.68586738111, 78, 327231, 14030.0, 43534.200000000004, 50834.0, 53780.02, 0.15944105710809164, 0.053126508776413235, 0.06752731826415999], "isController": false}, {"data": ["student details", 1495, 179, 11.97324414715719, 69559.67892976588, 313, 442486, 32697.0, 376162.2000000001, 386275.0, 391440.39999999997, 0.1648186217921969, 1.6636271974484094, 0.020969242089009334], "isController": false}, {"data": ["delete", 1493, 27, 1.8084393837910249, 31371.460817146664, 80, 58684, 31908.0, 52306.4, 54016.799999999996, 57247.34, 0.1597455882987052, 0.052435433605753236, 0.037885807362816465], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400/Bad Request", 54, 13.138686131386862, 0.4018156112806012], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 31, 7.542579075425791, 0.23067192499441921], "isController": false}, {"data": ["405/Method Not Allowed", 54, 13.138686131386862, 0.4018156112806012], "isController": false}, {"data": ["404/Not Found", 57, 13.86861313868613, 0.4241387007961902], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to www.thetestingworldapi.com:443 [www.thetestingworldapi.com/103.235.104.116] failed: Connection timed out: connect", 4, 0.9732360097323601, 0.02976411935411861], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 211, 51.338199513381994, 1.5700572959297567], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 13439, 411, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 211, "404/Not Found", 57, "400/Bad Request", 54, "405/Method Not Allowed", 54, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 31], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["create student", 1493, 27, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 27, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["create technical skill", 1493, 33, "400/Bad Request", 27, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 5, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 1, "", "", "", ""], "isController": false}, {"data": ["get specific student", 1493, 28, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 17, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 11, "", "", "", "", "", ""], "isController": false}, {"data": ["final student details", 1493, 28, "404/Not Found", 27, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 1, "", "", "", "", "", ""], "isController": false}, {"data": ["get deleted details", 1493, 27, "404/Not Found", 27, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["get address by id", 1493, 31, "405/Method Not Allowed", 27, "404/Not Found", 3, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 1, "", "", "", ""], "isController": false}, {"data": ["create student address", 1493, 31, "400/Bad Request", 27, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 2, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 2, "", "", "", ""], "isController": false}, {"data": ["student details", 1495, 179, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 168, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 7, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to www.thetestingworldapi.com:443 [www.thetestingworldapi.com/103.235.104.116] failed: Connection timed out: connect", 4, "", "", "", ""], "isController": false}, {"data": ["delete", 1493, 27, "405/Method Not Allowed", 27, "", "", "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
